Hello! Thank you for using ChardScript
Currently version is official 1.0.0
If you don't know how to use it, you can join Discord Server here:
https://discord.gg/dFHEtV5DXz